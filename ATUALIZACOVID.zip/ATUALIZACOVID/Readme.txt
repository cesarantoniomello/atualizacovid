Este é um programa para importação de dados do site
https://www.saude.pr.gov.br/Pagina/Coronavirus-COVID-19

Desenvolvido em Visual Studio 2019.
Utiliza o MDAC que pode ser baixado aqui 
https://www.microsoft.com/en-us/download/details.aspx?id=21995

Pode-se utilizar qualquer outro componente para conexão

O banco é MYSQL.

O arquivo geral2.sql gera a estrutura do Banco

O aqruivo geral2dados.sql gera a estrutura + dados do banco atualizado até 2021-02-26

A utilização é absolutamente livre.

